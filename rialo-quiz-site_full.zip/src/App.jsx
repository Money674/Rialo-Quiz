import React, { useState } from "react";

const quizData = [
  { question: "What does Rialo describe itself as?", options: ["A traditional Layer-1 blockchain","A real-world blockchain with native external connectivity","A DeFi lending protocol","A token swap DEX"], answer: 1 },
  { question: "Which company is building Rialo?", options: ["ConsenSys","Subzero Labs","Ethereum Foundation","Binance Labs"], answer: 1 },
  { question: "What is one of the key features of Rialo’s design?", options: ["No smart contract support","Native Web access for smart contracts (API calls)","Only supports ERC-20 tokens","Centralized custodial control"], answer: 1 },
  { question: "Rialo claims to support what kind of transaction speed?", options: ["Minutes","Hours","Sub-second","Days"], answer: 2 },
  { question: "Which of the following is a built-in capability of Rialo (as claimed)?", options: ["Oracles only","Bridges only","Scheduling, event-driven logic, privacy, identity","Only token minting"], answer: 2 },
  { question: "What does the acronym “Rialo” jokingly stand for (in one slogan)?", options: ["“Really Is A Layer One”","“Rialo Isn’t A Layer 1”","“Rialo Is Another L One”","“Rialo Is A Lean Option”"], answer: 1 },
  { question: "Who are the co-founders of Rialo?", options: ["Vitalik Buterin & Gavin Wood","Sam Bankman & Caroline Ellison","Ade Adepoju & Lu Zhang","Changpeng Zhao & He Yi"], answer: 2 },
  { question: "How much funding has Rialo raised (in its early round) according to sources?", options: ["$1 million","$5 million","$20 million","$100 million"], answer: 2 },
  { question: "Which investors are mentioned as backers of Rialo?", options: ["Sequoia, SoftBank","Pantera Capital, Coinbase Ventures, Hashed, Variant","Tiger Global, Coatue","BlackRock, Fidelity"], answer: 1 },
  { question: "Rialo supports which virtual machine compatibility?", options: ["EVM only","Solana VM compatibility","Bitcoin VM","Cardano VM"], answer: 0 },
  { question: "What is one use case highlighted in a developer’s testimonial about Rialo?", options: ["Building gaming graphics","Automating event-triggered smart contract flows without cron jobs","Creating simple token minting","Designing wallets only"], answer: 1 },
  { question: "Which of the following is NOT claimed as a capability of Rialo?", options: ["Confidential computing / privacy","Identity via phone / email / social accounts","Built-in oracle marketplace only","Real-time execution and event scheduling"], answer: 2 },
  { question: "What problem is Rialo trying to solve in the Web3 / blockchain space?", options: ["High token inflation","The disconnection from off-chain data and reactive logic","Lack of NFTs","Limited wallet choices"], answer: 1 },
  { question: "When was Rialo founded (or first publicly introduced)?", options: ["2017","2020","2025","2030"], answer: 2 },
  { question: "What is one feature that Rialo claims removes the need for (traditional) bridges?", options: ["Native data and asset flow across ecosystems","Manual token wrapping only","Custodial transfer service","Centralized exchange reliance"], answer: 0 }
];

export default function App() {
  const [current, setCurrent] = useState(0);
  const [score, setScore] = useState(0);
  const [showScore, setShowScore] = useState(false);

  const handleAnswer = (index) => {
    if (index === quizData[current].answer) setScore(score + 1);
    const next = current + 1;
    if (next < quizData.length) setCurrent(next);
    else setShowScore(true);
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-gradient-to-br from-indigo-900 via-purple-900 to-black text-white p-6">
      <div className="bg-gray-800 rounded-2xl shadow-2xl p-8 max-w-xl w-full text-center">
        <h1 className="text-3xl font-bold mb-6 text-purple-300 animate-pulse">Rialo Quiz</h1>
        {showScore ? (
          <div>
            <h2 className="text-2xl mb-4">You scored {score} out of {quizData.length}</h2>
            <button className="bg-purple-600 hover:bg-purple-700 text-white px-6 py-2 rounded-xl mt-4"
              onClick={() => { setScore(0); setCurrent(0); setShowScore(false); }}>
              Restart Quiz
            </button>
          </div>
        ) : (
          <div>
            <h2 className="text-xl mb-4">{quizData[current].question}</h2>
            <div className="grid gap-3">
              {quizData[current].options.map((opt, i) => (
                <button key={i} onClick={() => handleAnswer(i)} className="bg-purple-600 hover:bg-purple-700 px-4 py-2 rounded-xl">{opt}</button>
              ))}
            </div>
          </div>
        )}
      </div>

      <footer className="mt-8 text-gray-400 text-sm flex items-center gap-2 fixed bottom-4">
        <span>Made with ❤️ by </span>
        <a href="https://x.com/zurelcrypto" target="_blank" rel="noopener noreferrer"
          className="text-purple-400 hover:underline flex items-center gap-1">
          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="currentColor" className="inline-block">
            <path d="M23.954 4.569c-.885.392-1.83.656-2.825.775 1.014-.611 
              1.794-1.574 2.163-2.724-.951.564-2.005.974-3.127 
              1.195-.897-.956-2.178-1.553-3.594-1.553-2.723 
              0-4.928 2.204-4.928 4.928 0 .39.045.765.127 
              1.124-4.094-.205-7.725-2.165-10.158-5.144-.424.729-.666 
              1.577-.666 2.475 0 1.709.87 3.216 2.188 
              4.099-.807-.025-1.566-.248-2.228-.616v.062c0 
              2.385 1.693 4.374 3.946 4.827-.413.111-.849.171-1.296.171-.317 
              0-.626-.031-.928-.089.627 1.956 2.444 3.379 4.6 
              3.421-1.68 1.318-3.809 2.105-6.102 
              2.105-.396 0-.788-.023-1.175-.069 2.179 
              1.396 4.768 2.209 7.557 2.209 9.054 0 
              14-7.496 14-13.986 0-.213-.005-.425-.014-.636.962-.695 
              1.8-1.562 2.46-2.549z" />
          </svg>
          Zurel
        </a>
      </footer>
    </div>
  );
}
